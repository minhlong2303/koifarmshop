

function CartHistory() {
  return <div>CartHistory</div>;
}

export default CartHistory;
