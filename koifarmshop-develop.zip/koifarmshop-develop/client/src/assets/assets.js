
import Bekko from "./Bekko.jpg"
import Doitsu from "./Doitsu.jpg"
import Ginrin from "./Ginrin.jpg"
import Goshiki from "./Goshiki.jpg"
import Hirenaga from "./Hirenaga.jpg"
import Kawarimono from "./Kawarimono.jpg"
import Kikokuryu from "./Kikokuryu.jpg"
import Kohaku from "./Kohaku.jpg"
import Koromo from "./Koromo.jpg"
import platinum from "./platinum.jpg"
import Showa from "./Showa.jpg"
import taisho from "./taisho.jpg"
import tancho from "./tancho.jpg"
import Utsurimono from "./Utsurimono.jpg"

export const koi_list = [
    {
        koi_name: "Bekko",
        koi_image: Bekko
    },
    {
        koi_name: "Doitsu",
        koi_image: Doitsu
    },
    {
        koi_name: "Ginrin",
        koi_image: Ginrin
    },
    {
        koi_name: "Goshiki",
        koi_image: Goshiki
    },
    {
        koi_name: "Hirenaga",
        koi_image: Hirenaga
    },
    {
        koi_name: "Kawarimono",
        koi_image: Kawarimono
    },
    {
        koi_name: "Kikokuryu",
        koi_image: Kikokuryu
    },
    {
        koi_name: "Kohaku",
        koi_image: Kohaku
    },
    {
        koi_name: "Koromo",
        koi_image: Koromo
    },
    {
        koi_name: "Platinum",
        koi_image: platinum
    },
    {
        koi_name: "Showa",
        koi_image: Showa
    },
    {
        koi_name: "Taisho",
        koi_image: taisho
    },
    {
        koi_name: "Tancho",
        koi_image: tancho
    },
    {
        koi_name: "Utsurimono",
        koi_image: Utsurimono
    },
    
    ]
